package test3;

import java.util.List;

public interface Data {
    public abstract Mydata getContent();
}
